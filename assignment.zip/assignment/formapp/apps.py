from django.apps import AppConfig


class FormappConfig(AppConfig):
    name = 'formapp'
