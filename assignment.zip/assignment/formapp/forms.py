from django import forms
class StudentM(forms.Form):
     Namef = forms.CharField(max_length=20)
     Roll_Nof = forms.IntegerField()
     Marks_Mathsf = forms.IntegerField()
     Marks_Phyf = forms.IntegerField()
     Marks_Chef = forms.IntegerField()
     Totalf= forms.IntegerField()
     Percentagef= forms.IntegerField()


# from django import forms
# class FormClassName(forms.Form):
#     Name = forms.CharField()
#     email = forms.EmailField()
# class SecondForm(forms.Form):
#     FIRST__NAME= forms.CharField()
#     LAST__NAME= forms.CharField()