from django.shortcuts import render
from django.http import HttpResponse
from .forms import StudentM
from .models import NameModel


def page1(request):
    return render(request,"page1.html")
def page2(request):
    sm=StudentM()
    return render(request,"page2.html",{'form':sm})
def new(request):
    if request.method == 'POST':
        Name=request.POST["Namef"]
        Roll_No=request.POST["Roll_Nof"]
        Marks_Maths=request.POST["Marks_Mathsf"]
        Marks_Phy=request.POST["Marks_Phyf"]
        Marks_Che=request.POST["Marks_Chef"]
        Total=request.POST["Totalf"]
        Percentage=request.POST["Percentagef"]
       

        NameModel2=NameModel(Name=Name,
                         Roll_No=Roll_No,
                         Marks_Maths=Marks_Maths,
                         Marks_Che=Marks_Che,
                         Marks_Phy=Marks_Phy,
                         Total=Total,
                         Percentage=Percentage,
                          )
        NameModel2.save()
        
    
        return render(request,"page3.html")
    else:
        sm=StudentM()
        return render(request,"page3.html")
def percent(request):
    print("runned")
    x1=int(request.GET["Marks_Mathsf"])
    x2=int(request.GET["Marks_Phyf"])
    x3=int(request.GET["Marks_Chef"])
    p=((x1+x2+x3)//3)
    context={
        "val":p
    }
    
    return render(request,"test.html",context)

